import React from 'react'

function Register() {
    return (
        <div>Register</div>
    )
}

export default Register